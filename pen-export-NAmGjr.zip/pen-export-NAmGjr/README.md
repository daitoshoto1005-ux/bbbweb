# 日本語

A Pen created on CodePen.

Original URL: [https://codepen.io/hex/pen/NrmGjM](https://codepen.io/hex/pen/NrmGjM).

Click on any of the Japanese words to get a detailed view of them.
The words are colored according to the parts of speech.